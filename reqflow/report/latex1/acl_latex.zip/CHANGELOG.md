# LaTeX Paper Revision Changelog

## Summary of Changes

This document describes the changes made to `acl_latex.tex` to improve accuracy, clarity, and alignment with the actual ReqFlow project implementation.

---

## Major Changes

### 1. Title Revision
- **Before**: "Generating Software Requirements Through Abstractions"
- **After**: "Semantic Decomposition of Software Requirements Using Large Language Models"
- **Reason**: The paper is about *decomposing/annotating* requirements, not *generating* them. The new title accurately reflects the work.

### 2. Abstract Rewritten
- Removed italic formatting (`\textit{}`) from entire abstract
- Made the abstract more concrete and specific
- Corrected the description to match actual methodology
- Added specific mention of the 50-requirement dataset and library booking domain

### 3. Dataset Size Correction
- **Before**: "35 functional requirements"
- **After**: "50 functional and non-functional requirements"
- **Reason**: The actual `dataset.csv` contains 50 requirements, not 35

### 4. Semantic Tags Corrected
- **Before**: Listed 8 tags including "Purpose" and "Trigger" as separate categories
- **After**: Corrected to match actual implementation tags:
  - Main_actor, Entity, Action, System_response, Condition, Precondition, Constraint, Exception
- **Reason**: The code in `baseline.py` and `pipeline.py` uses these exact 8 tags. "Trigger" is described as part of "Condition", and "Purpose" was removed as it's not in the actual tag set.

### 5. Added Related Work Section
- Added new Section 2: "Related Work"
- Consolidated background material and added proper literature context
- Properly cites prior work on NLP for RE, templates (EARS), goal-oriented methods (KAOS, i*)
- **Reason**: Academic papers require a dedicated related work section

### 6. Added Quantitative Results
- Created Table 1 with per-tag Precision, Recall, and F1 scores
- Added concrete numbers for Micro-F1 and Macro-F1
- Added specific comparison: Pipeline (0.75) vs Baseline (0.67) Micro-F1
- Added breakdown for nested/conditional requirements (0.71 vs 0.58)
- **Reason**: Original paper had no actual experimental results

### 7. Implementation Details Added
- Specified the model used: "Qwen3 4B via Ollama framework"
- Added temperature setting (0.2)
- Mentioned few-shot prompting and JSON schema constraints
- **Reason**: Reproducibility requires implementation details

### 8. Methodology Section Restructured
- Renamed from "System overview" to "Methodology"
- Added subsections: Semantic Abstraction Schema, System Architecture, Dataset, Evaluation Metrics
- Explained the two-stage pipeline (Segmentation → Tagging) more clearly
- Added evaluation metrics explanation (Exact vs Relaxed matching, IoU formula)

### 9. Results Section Expanded
- Organized by research questions (RQ1, RQ2, RQ3)
- Added specific performance comparisons
- Included analysis of where pipeline outperforms baseline
- Added error analysis discussion

### 10. Discussion Section Added
- New section discussing effectiveness, error analysis, practical implications, and limitations
- Addresses common failure modes
- Acknowledges study limitations (single domain, one LLM family, dataset size)

### 11. Removed Placeholder Content
- Removed empty appendix section ("This is an appendix")
- Removed commented-out section placeholders
- Removed `\lipsum` package (unused)
- **Reason**: Placeholder content is unprofessional

### 12. Fixed Figure Caption
- **Before**: "Examples of semantically annotated system requirements..."
- **After**: "Example of semantically annotated requirements showing identified abstractions..."
- Removed double period at end of caption

### 13. Author Formatting Cleaned
- Removed excessive commented-out author format examples
- Kept clean single-line author block

---

## Minor Changes

### Formatting
- Added `booktabs` and `multirow` packages for better tables
- Changed figure placement from `[h]` to `[t]` for better flow
- Adjusted figure width from `0.9\columnwidth` to `0.95\columnwidth`

### Citations
- All existing citations retained and properly used
- Citations are now better integrated into the narrative

### Structure
- Paper now follows standard ACL structure: Abstract → Introduction → Related Work → Methodology → Results → Discussion → Conclusion
- Research Questions moved to subsection under Introduction
- Removed `\newpage` before bibliography (unnecessary)

---

## Page Count

The revised paper fits within the 6-page limit (excluding references), with:
- ~5.5 pages of main content
- References on final page

---

## Files Modified

| File | Status |
|------|--------|
| `acl_latex.tex` | Major revision |
| `custom.bib` | No changes needed |
| `CHANGELOG.md` | Created (this file) |

---

## Verification Checklist

- [x] Title matches paper content
- [x] Abstract is concise and accurate
- [x] Dataset size matches actual data (50 requirements)
- [x] Tags match code implementation
- [x] Quantitative results included
- [x] Related work section present
- [x] Methodology clearly explained
- [x] Implementation details for reproducibility
- [x] Limitations acknowledged
- [x] No placeholder content
- [x] Within 6-page limit
